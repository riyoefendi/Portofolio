-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 20 Agu 2025 pada 15.42
-- Versi server: 8.4.3
-- Versi PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portofolio`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `about`
--

CREATE TABLE `about` (
  `id` int NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `birthday` text NOT NULL,
  `website` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `age` varchar(50) NOT NULL,
  `degree` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `freelance` varchar(50) NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `about`
--

INSERT INTO `about` (`id`, `title`, `content`, `image`, `birthday`, `website`, `city`, `phone`, `age`, `degree`, `email`, `freelance`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'About', '<p class=\"MsoNormal\" style=\"margin-top:4.05pt;mso-pagination:none\"><span style=\"font-family:\"Trebuchet MS\",sans-serif;mso-fareast-font-family:\"Trebuchet MS\";\r\nmso-bidi-font-family:\"Trebuchet MS\";color:#262626\">Saya lulusan dari\r\nUniversitas Nasional dengan jurusan Sistem Informasi. Minat saya pada bidang\r\ninformasi dan teknologi serta administrasi. Saya mempunyai pengalaman analisa\r\nkeuangan perorangan maupun perusahaan dalam rangka pembiayaan kredit dengan\r\nmenggunakan sistem dari perusahaan dan saya memiliki pengalaman stok barang,\r\nserta melakukan pengembangan di bidang teknologi informasi.<o:p></o:p></span></p>', '36c1795accb3bbc9cf01183ea64d8ce7.jpg', '2025-08-05', 'https://www.linkedin.com/in/riyo-efendi-a59115216/', 'Jakarta Selatan', '082191922016', '27', 'Sistem Informasi', 'riyo@gmail.com', 'Web Developer', 1, '2025-08-18 12:04:39', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `categories`
--

CREATE TABLE `categories` (
  `id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'App', '2025-08-20 15:05:51', NULL),
(2, 'Web', '2025-08-20 15:05:56', NULL),
(3, 'Desain', '2025-08-20 15:06:04', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `contact`
--

CREATE TABLE `contact` (
  `id` int NOT NULL,
  `content` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `lokasi` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `contact`
--

INSERT INTO `contact` (`id`, `content`, `lokasi`, `email`, `phone`, `created_at`, `updated_at`) VALUES
(1, '<p>adasdasdsadasdsa</p>', 'dsadas', 'riyo@gmail.com', '089616682955', '2025-08-20 07:11:07', '2025-08-20 15:00:31');

-- --------------------------------------------------------

--
-- Struktur dari tabel `portofolios`
--

CREATE TABLE `portofolios` (
  `id` int NOT NULL,
  `id_category` int NOT NULL,
  `nama_project` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `link` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `portofolios`
--

INSERT INTO `portofolios` (`id`, `id_category`, `nama_project`, `link`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 3, 'Project Compro 2025', 'http://localhost/portofolio-main/', '<p>Ini adalah project compro saya di ppkdjp</p>', '23102eca80c165eefbaab727b725198d.jpeg', '2025-08-20 15:24:28', '2025-08-20 15:25:08'),
(2, 2, 'Hotel Apps', 'http://localhost/hotel_apps/', 'Ini adalah project hotel saya', 'fd8b1d4aa77b7f33d3a8941b14d663d5.png', '2025-08-20 15:39:31', NULL),
(3, 1, 'Project laravel Apps 2025', 'http://localhost/laravel_apps/', '<p>Ini adalah [project aplikasi saya di ppkd</p>', '96969eb1a46d59011415942aa783b223.jpg', '2025-08-20 15:41:25', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `resume`
--

CREATE TABLE `resume` (
  `id` int NOT NULL,
  `education` varchar(100) NOT NULL,
  `tahun_education` varchar(100) NOT NULL,
  `prodi` varchar(50) NOT NULL,
  `isi_prodi` text NOT NULL,
  `pengalaman` varchar(50) NOT NULL,
  `tahun_pengalaman` varchar(50) NOT NULL,
  `lokasi_kerja` varchar(50) NOT NULL,
  `jobdesk` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `resume`
--

INSERT INTO `resume` (`id`, `education`, `tahun_education`, `prodi`, `isi_prodi`, `pengalaman`, `tahun_pengalaman`, `lokasi_kerja`, `jobdesk`, `created_at`, `updated_at`) VALUES
(1, 'kjkljk', '212', 'kjkljklK', 'kljkljkl', 'ljklj', '2222', 'kkljL', 'jhjkhjkhjk', '2025-08-20 04:55:00', '2025-08-20 07:19:51');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'Riyo Efendi', 'riyo@gmail.com', 'efendi', '2025-08-18 02:02:47', '2025-08-18 02:02:47');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `portofolios`
--
ALTER TABLE `portofolios`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `resume`
--
ALTER TABLE `resume`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `about`
--
ALTER TABLE `about`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `portofolios`
--
ALTER TABLE `portofolios`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `resume`
--
ALTER TABLE `resume`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
