<header id="header" class="header dark-background d-flex flex-column">
    <i class="header-toggle d-xl-none bi bi-list"></i>

    <div class="profile-img">
        <img
            src="assets1/assets/img/my-profile-img.jpg"
            alt=""
            class="img-fluid rounded-circle" />
    </div>

    <a
        href="index.html"
        class="logo d-flex align-items-center justify-content-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1 class="sitename">Alex Smith</h1>
    </a>

    <div class="social-links text-center">
        <a href="#" class="twitter"><i class="bi bi-twitter-x"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bi bi-skype"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
    </div>

    <nav id="navmenu" class="navmenu">
        <ul>
            <li>
                <a href="?page=hero"><i class="bi bi-house navicon"></i>Home</a>
            </li>
            <li>
                <a href="?page=about"><i class="bi bi-person navicon"></i> About</a>
            </li>
            <li>
                <a href="?page=skills"><i class="bi bi-file-earmark-text navicon"></i> Skills</a>
            </li>
            <li>
                <a href="?page=portofolio"><i class="bi bi-images navicon"></i> Portfolio</a>
            </li>
            <li>
                <a href="#services"><i class="bi bi-hdd-stack navicon"></i> Services</a>
            </li>
            <li class="dropdown">
                <a href="#"><i class="bi bi-menu-button navicon"></i> <span>Dropdown</span>
                    <i class="bi bi-chevron-down toggle-dropdown"></i></a>
                <ul>
                    <li><a href="#">Dropdown 1</a></li>
                    <li class="dropdown">
                        <a href="#"><span>Deep Dropdown</span>
                            <i class="bi bi-chevron-down toggle-dropdown"></i></a>
                        <ul>
                            <li><a href="#">Deep Dropdown 1</a></li>
                            <li><a href="#">Deep Dropdown 2</a></li>
                            <li><a href="#">Deep Dropdown 3</a></li>
                            <li><a href="#">Deep Dropdown 4</a></li>
                            <li><a href="#">Deep Dropdown 5</a></li>
                        </ul>
                    </li>
                    <li><a href="#">Dropdown 2</a></li>
                    <li><a href="#">Dropdown 3</a></li>
                    <li><a href="#">Dropdown 4</a></li>
                </ul>
            </li>
            <li>
                <a href="?page=contact"><i class="bi bi-envelope navicon"></i> Contact</a>
            </li>
        </ul>
    </nav>
</header>